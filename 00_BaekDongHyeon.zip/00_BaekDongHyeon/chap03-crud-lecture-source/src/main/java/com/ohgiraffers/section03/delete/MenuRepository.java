package com.ohgiraffers.section03.delete;

public class MenuRepository {
}
